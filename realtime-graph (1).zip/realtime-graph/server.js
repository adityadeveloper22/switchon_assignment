// server.js

    var express               = require('express'),
        path                  = require('path'),
        bodyParser            = require("body-parser"),
        mongoose              = require("mongoose"),
        passport              = require("passport"),
        User                  = require("./model/user"),
        LocalStrategy         = require("passport-local"),
        passportLocalMongoose = require("passport-local-mongoose"),
        app                   = express();
    
    mongoose.connect("mongodb://localhost/auth", { useNewUrlParser: true });

    app.use(bodyParser.urlencoded({extended: true}));
    app.set("view engine", "ejs");
    app.use(express.static("public"));
    app.use(require("express-session")({
    secret: "Everything is okay",
    resave: false,
    saveUninitialized: false
}));
    app.use(passport.initialize());
    app.use(passport.session());
    
    passport.use(new LocalStrategy(User.authenticate()));
    passport.serializeUser(User.serializeUser());
    passport.deserializeUser(User.deserializeUser());

    

    var PartHistorySchema = new mongoose.Schema({
    numberOfParts: Number,
    name: {type: Date, default: Date},
     time: String
});
    var PartHistory = mongoose.model("PartHistory", PartHistorySchema);


//==========
//Routes
//==========

app.get("/",function(req, res) {
    res.render("login");
});

//My Data page
app.get("/app.js",function(req, res) {
  res.sendFile(path.join(__dirname+'/app.js'));
});
    
app.get("/data", function(req, res){
   PartHistory.find({}, function(err, parts){
       if(err){
           console.log("ERROR!");
       } else {
          // res.render("index", {parts: parts}); 
          res.send(parts);
       }
   });
});
app.get("/graph",isLoggedIn,function(req, res) {
    PartHistory.find({}, function(err, parts){
       if(err){
           console.log("ERROR!");
       } else {
          res.render("page", {parts: parts}); 
       }
   });

    
});
    app.get("/data/new",isLoggedIn, function(req, res){
    res.render("graph");
});
app.get("/register", function(req, res){
    res.render("register"); 
    });
app.post("/data", function(req, res){
    // create blog
    console.log(req.body);
    console.log("===========")
    console.log(req.body);
    PartHistory.create(req.body.PartHistory, function(err, parts){
        if(err){
            res.render("new");
        } else {
            //then, redirect to the index
            console.log(parts);
            res.redirect("/graph");
        }
    });
});
 //Auth Routes
    
    
    
    app.post("/register", function(req, res){
    User.register(new User({username: req.body.username}), req.body.password, function(err, user){
        if(err){
            console.log(err);
            return res.render('register');
        }
        passport.authenticate("local")(req, res, function(){
           res.redirect("/graph");
        });
    });
});
app.get("/login", function(req, res){
   res.render("login"); 
});
app.post("/login", passport.authenticate("local", {
    successRedirect: "/graph",
    failureRedirect: "/login"
}) ,function(req, res){
});

app.get("/logout", function(req, res){
    req.logout();
    res.redirect("/");
});


function isLoggedIn(req, res, next){
    if(req.isAuthenticated()){
        return next();
    }
    res.redirect("/login");
}
    app.listen(process.env.PORT,process.env.IP,function(){
      console.log("Server started");
    });